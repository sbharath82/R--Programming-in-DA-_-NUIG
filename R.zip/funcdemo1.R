evans<- function(x){
  if x[x%%2=0] return(x)}

