library(tidyr)
library(readxl)

x<- read_excel("R/datasets/ExamDataBroad.xlsx")


